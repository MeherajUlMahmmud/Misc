from django.urls import path

from .views import palindrome_home_view, palindrome_check_view

urlpatterns = [
    path('', palindrome_home_view, name='palindrome'),
    path('palindrome-check/', palindrome_check_view, name='palindrome_check'),
]
