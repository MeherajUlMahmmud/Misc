from django.shortcuts import render


def palindrome_home_view(request):
    return render(request, 'palindrome/palindrome.html')


def palindrome_check_view(request):
    if request.method == 'POST':
        word = request.POST.get('word', '').lower().replace(' ', '')
        is_palindrome = word == word[::-1]
        return render(request, 'palindrome/palindrome_check.html', {'word': word, 'is_palindrome': is_palindrome})
    return render(request, 'palindrome/palindrome_check.html')
